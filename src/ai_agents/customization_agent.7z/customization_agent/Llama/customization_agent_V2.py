import openai
from docx import Document
import requests
import logging

# Ollama API configuration
openai.api_base = "http://localhost:11434/v1"
openai.api_key = "ollama"

def load_cv(file_path):
    """Loads the content of the CV from a Word file."""
    try:
        doc = Document(file_path)
        content = "\n".join(paragraph.text for paragraph in doc.paragraphs if paragraph.text.strip())
        return content
    except Exception as e:
        logging.error(f"Error loading file {file_path}: {e}")
        return ""

def save_cv(content, file_path):
    """Saves the customized CV content to a Word file."""
    try:
        doc = Document()
        for line in content.split("\n"):
            if line.strip():  # Ignore empty lines
                doc.add_paragraph(line)
        doc.save(file_path)
        logging.info(f"Customized CV saved at: {file_path}")
    except Exception as e:
        logging.error(f"Error saving file {file_path}: {e}")

def save_cv_json(data, file_path):
    """Guarda los datos del CV en formato JSON."""
    try:
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=4)
        logging.info(f"Customized CV data saved in JSON format at: {file_path}")
    except Exception as e:
        logging.error(f"Error saving JSON file {file_path}: {e}")

def send_prompt_to_ollama(prompt, max_tokens=1500):
    """Sends a prompt to Ollama and returns the response."""
    url = "http://localhost:11434/v1/completions"
    payload = {
        "model": "llama3.1:8b",
        "prompt": prompt,
        "max_tokens": max_tokens
    }
    headers = {"Content-Type": "application/json"}
    try:
        logging.info("Sending the following prompt to the server:")
        logging.info(prompt)
        response = requests.post(url, json=payload, headers=headers, timeout=240)
        response.raise_for_status()
        result = response.json()
        text = result.get("text", "").strip()
        if not text and "choices" in result:
            text = result["choices"][0].get("text", "").strip()
        return text
    except requests.exceptions.HTTPError as http_err:
        logging.error(f"HTTP error: {http_err}")
        if response in locals():
            logging.error(f"Server response: {response.text}")
        return ""
    except requests.exceptions.RequestException as req_err:
        logging.error(f"Request error to Ollama: {req_err}")
        return ""

# ================================
# Agent 1: Analysis
# ================================
def analyze_cv_skills(cv_content):
    """Analyzes the CV and extracts key skills."""
    prompt = f"""
Analyze the following CV and extract:
1. A clear and complete list of all the skills mentioned in the document.

CV:
{cv_content}
"""
    return send_prompt_to_ollama(prompt)

def analyze_job_requirements(job_description):
    """Analyzes the job description and extracts key requirements."""
    prompt = f"""
Analyze the following job description and extract:
1. The key requirements (skills, experience, tools).
2. The primary responsibilities of the role.

Job Description:
{job_description}
"""
    return send_prompt_to_ollama(prompt)

# ================================
# Agent 2: Generating Recommendations
# ================================
def generate_cv_recommendations(cv_skills, job_requirements):
    """Generates recommendations by comparing the CV analysis with the job description."""
    prompt = f"""
Based on the following analyses:
1. CV skills: {cv_skills}
2. Job description requirements: {job_requirements}

Generate detailed recommendations to customize the CV. Identify:
- Additional skills or experiences that should be highlighted.
- Areas that need adjustments or emphasis to better align the CV with the job description.
"""
    return send_prompt_to_ollama(prompt)

# ================================
# Agent 3: Customizing the CV
# ================================

def customize_cv(original_cv, cv_skills, job_requirements):
    """
    Generates a customized version of the CV by improving the language and structure
    clearly emphasizing the candidate's relevant skills and experiences required by the job offer,
    while preserving the original sections (Summary, Skills, Experience, Education).
    """
    prompt = f"""
Using the information below, generate a revised version of the CV that improves the wording and structure 
to clearly emphasize the candidate's relevant skills and experiences required by the job offer. 
Make sure to preserve the original sections (Summary, Skills, Experience, Education) as they appear in the CV. 
Do not invent any new content; only enhance the existing information.

Original CV:
{original_cv}

Extracted Skills from CV:
{cv_skills}

Job Description and Requirements:
{job_requirements}

Please rewrite and reorganize the CV to better showcase the candidate's skills and experience. 
The new version should maintain the sections as originally provided and use a professional tone.
"""
    return send_prompt_to_ollama(prompt)

def main():
    # File paths and job description
    cv_path = "C:/Test/Diana_Mayorga.docx"
    output_path = "C:/Test/customized_cv.docx"
    job_description = """Who You'll Work With

The Data Analyst will be reporting directly to the Director of Operations.

What You'll Be Doing

Generate, maintain and deliver detailed customer reports by analyzing and interpreting complex data sets to identify trends, patterns, and actionable insights
Work with multiple datasets from various sources, combining and restructuring data to create comprehensive datasets that support robust analysis
Identify opportunities to improve existing reporting processes and systems, implementing best practices in data analysis and visualization
Maintain thorough documentation of data processes, methodologies, and reporting procedures for reference and compliance purposes
Track reporting requirements and deadlines
Ensure completion and accuracy of weekly/monthly/quarterly customer reports
Develop thorough understanding of customer valued metrics and KPIs
Work collaboratively with other analytics teams and business subject matter experts to refine personal understanding and ensure consistency in reporting and design
Understand and communicate standards, SLAs and processes for our metrics and reporting
Ensure privacy and confidentiality is maintained through all analysis and reporting
What You Need to Be Successful

Post-secondary degree or diploma, ideally in business and/or data analytics, or related experience
Minimum 2 years of experience in data analysis, customer reporting, or a similar role
Advanced Excel skills, including:
Pivot tables, VLOOKUPs, and complex formula creation
Experience in creating, running, and troubleshooting macros to automate repetitive tasks, streamlining data processing, and enhancing reporting efficiency
Experience with Excel’s advanced data manipulation tools, such as Power Query, to efficiently handle large and complex datasets
Proficiency in SQL for querying and manipulating large datasets
Experience with Power BI
Familiarity with data warehousing, ETL processes, and data management best practices
Skills an Ideal Candidate Would Have

Excellent problem-solving skills with the ability to analyze and interpret complex data sets to derive meaningful insights
Strong written and verbal communication skills, with the ability to present data-driven insights clearly to non-technical stakeholders
Meticulous attention to detail, with a strong focus on accuracy and consistency in data analysis
Ability to work effectively in a collaborative, fast-paced environment.
"""

    # Load the CV
    cv_content = load_cv(cv_path)
    if not cv_content:
        print("Failed to load the CV.")
        return

    # Step 1: Analyze CV skills
    logging.info("Analyzing CV skills...")
    cv_skills = analyze_cv_skills(cv_content)
    if not cv_skills:
        print("Error analyzing CV skills.")
        return
    print("Extracted skills from the CV:")
    print(cv_skills)

    # Step 2: Analyze job requirements
    logging.info("Analyzing job description requirements...")
    job_requirements = analyze_job_requirements(job_description)
    if not job_requirements:
        print("Error analyzing job description.")
        return
    print("Key requirements from the job description:")
    print(job_requirements)

    # Step 3: Generate recommendations
    logging.info("Generating recommendations to customize the CV...")
    recommendations = generate_cv_recommendations(cv_skills, job_requirements)
    if not recommendations:
        print("Error generating recommendations.")
        return
    print("Recommendations to customize the CV:")
    print(recommendations)

    # Step 4: Generate a customized CV
    logging.info("Generating a customized CV...")
    customized_cv = customize_cv(cv_content, cv_skills, job_requirements)
    if not customized_cv:
        print("Error generating the customized CV.")
        return
    print("Customized CV:")
    print(customized_cv)

    # Confirm and save the customized CV
    user_response = input("Do you want to save the customized CV? (y/n): ").strip().lower()
    if user_response == "y":
        save_cv(recommendations, output_path)
    else:
        print("The customized CV was not generated.")

if __name__ == "__main__":
    main()
